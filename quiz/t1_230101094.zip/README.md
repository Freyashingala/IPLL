Commands used:
    nasm -f elf32 t1_230101094.asm -o t1_230101094.o
    gcc -m32 t1_230101094.o -o t1_230101094
    ./t1_230101094